<?php

class Mage_Ecomcharge_Helper_Data extends Mage_Core_Helper_Abstract
{

}
